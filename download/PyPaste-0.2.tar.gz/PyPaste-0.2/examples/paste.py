#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) 2009, 2010 Timur Birsh

This file is part of PyPaste - Paste.kz API implementation

PyPaste is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

PyPaste is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

@author: Timur Birsh <taem@linukz.org>

"""

# Enable absolute imports
from __future__ import absolute_import

# Standard libraries
import sys

# PyPaste
import pypaste

def main():
    if len(sys.argv) != 2:
        print "Usage: paste.py <syntax>"
        print "Data to send program reads from stdin."
        sys.exit(1)

    syntax = sys.argv[1]

    # Read data
    data = sys.stdin.read()
    
    # Instance Paste object
    p = pypaste.Paste()
    try:
        # Use paste() method to send text
        result = p.paste(data, syntax)
    except pypaste.PasteError, e:  # Use PasteError to catch exceptions
        print "Error: ", e.message
    else:
        # paste() returns True if request successful
        if result:
            # Use "url" property to get link to text
            print p.url
        # And False in case of error
        else:
            print "Something wrong"

if __name__ == "__main__":
    main()
