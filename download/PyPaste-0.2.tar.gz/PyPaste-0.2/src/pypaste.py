# -*- coding: utf-8 -*-
"""
Copyright (C) 2009, 2010 Timur Birsh

This file is part of PyPaste - Paste.kz API implementation

PyPaste is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

PyPaste is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

@author: Timur Birsh <taem@linukz.org>

"""

# Enable absolute imports
from __future__ import absolute_import

# HTTP
import urllib
import urllib2

class PasteError(Exception):
    """Base Paste exception"""
    def __init__(self, message="", original=None):
        Exception.__init__(self, message)
        self.original = original
        
class Paste(object):
    """Paste.KZ API implementation

    Use method `paste(data, syntax)` to send text. Please refer to its
    docstring for more infomation.
    
    """
    def __init__(self):
        # API handler
        self._handler = "http://www.mbyte.kz/paste/"

        # Result URL
        self._url = ""

    @property
    def url(self):
        """Get URL"""
        return self._url

    def _request(self, url, query):
        """Send data and get URL"""
        req = urllib2.Request(url, query)
        try:
            response = urllib2.urlopen(req)
        except urllib2.HTTPError, e:
            raise PasteError(u"Server responded with: %s." % (e.message), e)
        except urllib2.URLError, e:
            raise PasteError(u"Failed to connect to server.", e)

        return response.geturl()

    def paste(self, data, syntax="text"):
        """Paste text and set URL

        Arguments:
        *data*
          Text to send.
        *syntax*
          Syntax to use (default **text**).

        Function returns True if request successful and False in case of error.
        Use `url` property to get link.
        
        """
        # Don't allow empty data buffer
        if not data:
            raise PasteError(u"Empty data buffer!")

        if not syntax:
            syntax = "text"

        # Build query string
        query = urllib.urlencode({"language": syntax,
                                  "listing": data})

        self._url = self._request(self._handler, query)
        k = self._url.split("/")
        if k[-1].isdigit():
            return True
        else:
            return False
