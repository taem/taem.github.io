#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (C) 2009, 2010 Timur Birsh

This file is part of PyMurl.

PyMurl is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

PyMurl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

@author: Timur Birsh <taem@linukz.org>


"""

from distutils.core import setup

setup(
    name="PyMurl",
    version="0.3",
    description="Murl.kz API implementation",
    author="Timur Birsh",
    author_email="taem@linukz.org",
    url="http://linukz.org/murl.shtml",
    py_modules=["pymurl"],
    package_dir={"": "src"},
    data_files=[
        ("share/pymurl", [
                "examples/murl.py"
        ])
    ]
)
