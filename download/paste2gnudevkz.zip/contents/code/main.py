# -*- coding: utf-8 -*-
#
# KDE4 plasmoid for http://paste.gnudev.kz service
# Version 0.1
# Copyright (c) 2009 Timur Birsh <taem@linukz.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
                                        
import sys, os

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyKDE4.kdecore import *
from PyKDE4.kdeui import *
from PyKDE4.kio import *
from PyKDE4.plasma import Plasma
from PyKDE4 import plasmascript

class PasteGnuDevKZ(plasmascript.Applet):
    def __init__(self, parent, args=None):
        plasmascript.Applet.__init__(self, parent)
        self.__appletName = u"paste2gnudevkz"
        self.__postHandler = u"http://paste.gnudev.kz/addtopic"
 
    def init(self):
        print u"Initializing..."
        self.setAcceptDrops(True)
        self.setHasConfigurationInterface(False)
        self.setAspectRatioMode(Plasma.ConstrainedSquare)
        self.theme = Plasma.Svg(self)
        self.theme.setImagePath("widgets/background")
        self.setBackgroundHints(Plasma.Applet.DefaultBackground)
        self.layout = QGraphicsLinearLayout(self.applet)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.layout.setOrientation(Qt.Horizontal)
        self.icon = Plasma.IconWidget(KIcon("edit-paste"), "", self.applet)
        self.layout.addItem(self.icon)
        self.resize(self.icon.iconSize())

        self.checkNotifyrc()

    def pasteText(self):
        "Performs HTTP POST request"
        ba = QByteArray("form_name=Anonymous&form_lang=text&form_expire=forever&form_title=Text&form_text=")
        ba.append(QUrl.toPercentEncoding(self.data, "/"))

        print "Posting data..."
        self.job = KIO.http_post(KUrl(self.__postHandler), ba, KIO.HideProgressInfo)
        self.job.addMetaData("content-type", "Content-Type: application/x-www-form-urlencoded")
        self.connect(self.job, SIGNAL("redirection(KIO::Job*, const KUrl)"),
                     self.resultUrl)

    def resultUrl(self, job, url):
        "Catch URL from POST method handler"
        if not url.url().contains("id"):
            self.postError()
            return

        self.postFinished(url.url())

    def postError(self):
        self.doNotify(u"Problem with posting data.")

    def postFinished(self, url):
        clipboard = QApplication.clipboard()
        clipboard.setText(url)
        self.doNotify(u"Data posted succesfully: %s <br> Link has been copied to your clipboard." % url)

    def doNotify(self, msg):
        KNotification.event("text-link", msg, QPixmap(), None, KNotification.CloseOnTimeout, KComponentData("paste2gnudevkz-plasmoid", "paste2gnudevkz-plasmoid", KComponentData.SkipMainComponentRegistration))
    
    def checkNotifyrc(self):
        "Check notifyrc file and create it if needed"
        kdehome = str(KGlobal.dirs().localkdedir())
        appletDir = kdehome + u"share/apps/%s-plasmoid" % (self.__appletName)
        notifyRcFile = u"%s/%s-plasmoid.notifyrc" % (appletDir, self.__appletName)
        
        if not os.path.exists(notifyRcFile):
            if not os.path.isdir(appletDir):
                try:
                    os.mkdir(appletDir)
                except:
                    print u"Problem creating directory: ", appletDir
                    print u"Unexpected error: ", sys.exc_info()[0]

            rc = []
            rc.append(u"[Global]\n")
            rc.append(u"IconName=edit-paste\n")
            rc.append(u"Comment=paste.gnudev.kz plasmoid\n")
            rc.append(u"Name=paste2gnudevkz\n")
            rc.append(u"\n")
            rc.append(u"[Event/text-link]\n")
            rc.append(u"Name=Text Link\n")
            rc.append(u"Action=Popup\n")

            try:
                f = open(notifyRcFile, "w")
                f.writelines(rc)
                f.close()
            except:
                print u"Problem writing to file: ", notifyRcFile
                print u"Unexpected error:", sys.exc_info()[0]

    def dragEnterEvent(self, e):
        if e.mimeData().hasFormat('text/plain'):
            e.accept()
        else:
            e.ignore()

    def dropEvent(self, e):
        self.data = e.mimeData().text()
        self.pasteText()
            
def CreateApplet(parent):
    return PasteGnuDevKZ(parent)
