# -*- coding: utf-8 -*-
"""
Copyright (C) 2009, 2010 Timur Birsh

This file is part of PyMurl - Murl.kz API implementation

PyMurl is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

PyMurl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

@author: Timur Birsh <taem@linukz.org>

"""

# Enable absolute imports
from __future__ import absolute_import

# HTTP
import urllib
import urllib2

# XML
from xml.dom import minidom

# Regex
import re


# Murl response format
MURL_RESPONSE_FORMAT_XML = 0
MURL_RESPONSE_FORMAT_JSON = 1

# Murl response status
# "OK"
MURL_STATUS_OK = 0
# "ERROR"
MURL_STATUS_ERROR = 1
# Unknown response result
MURL_STATUS_UNKNOWN = 255


class NoRedirect(urllib2.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
        return headers
    def http_error_302(self, req, fp, code, msg, headers):
        return headers

class MurlError(Exception):
    """Base Murl exception"""
    def __init__(self, message="", original=None):
        Exception.__init__(self, message)
        self.original = original

class MurlResponseFormat(object):
    """Base response format"""
    def __init__(self):
        # There is no format yet
        self._format = None
        self._format_str = None
        # Query string
        self._query_string = None
        # Response fields
        self._fields = {"message": u"",
                        "code": u"",
                        "url": u"",
                        "murlpath": u""
                        }
        # Murl status
        self._status = None

        
    @property
    def format(self):
        """Get response format"""
        return self._format
    
    @property
    def format_str(self):
        """Get text representation of the response format"""
        return self._format_str
    
    @property
    def query_string(self):
        """Get query string"""
        return self._query_string
    
    @property
    def fields(self):
        """Get response fields"""
        return self._fields
    
    @property
    def status(self):
        """Get Murl status"""
        return self._status

    
    def build_query_string(self, in_vars):
        """Build query string

        Arguments:
        *in_vars*
          Dictionary of query components.

        """
        self._query_string = urllib.urlencode(in_vars)
            
    def parse(self, data):
        """Decode server raw reply"""
        raise NotImplementedError(u"Parsing not yet implemented!")

class MurlXmlResponse(MurlResponseFormat):
    """XML response"""
    def __init__(self):
        MurlResponseFormat.__init__(self)
        self._format = MURL_RESPONSE_FORMAT_XML
        self._format_str = "xml"

    def parse(self, data):
        """Parse XML response

        Arguments:
        *data*
          Murl server raw reply.

        Function returns True if XML parsed successfully and False in case
        of error.
        
        """
        result = u""

        # Parse XML
        try:
            dom = minidom.parseString(data)
            nodeStatus = dom.getElementsByTagName("status")[0]
            result = nodeStatus.attributes["result"].nodeValue
            self._fields["code"] = nodeStatus.attributes["code"].nodeValue
            self._fields["message"] = nodeStatus.attributes["message"].nodeValue
            if result == u"OK":
                self._status = MURL_STATUS_OK
                self._fields["url"] = \
                    dom.getElementsByTagName("url")[0].firstChild.nodeValue
                self._fields["murlpath"] = \
                    dom.getElementsByTagName("murlpath")[0].firstChild.nodeValue
            elif result == u"ERROR":
                self._status = MURL_STATUS_ERROR
            else:
                self._status = MURL_STATUS_UNKNOWN
        except:
            if dom:
                dom.unlink()
            return False
        
        dom.unlink()
        return True

class MurlJsonResponse(MurlResponseFormat):
    """JSON response"""
    def __init__(self):
        MurlResponseFormat.__init__(self)
        self._format = MURL_RESPONSE_FORMAT_JSON
        self._format_str = "json"

    def build_query_string(self, in_vars):
        """Build query string

        Arguments:
        *in_vars*
          Dictionary of query components.

        """
        MurlResponseFormat.build_query_string(self, in_vars)
        callback = urllib.urlencode({"callback": "?"})
        self._query_string = "%s&%s" % (self._query_string, callback)

class Murl(object):
    """Main Murl class

    Arguments:
    *key*
      API key.
    *format*
      Response format. Must be one of **MURL_RESPONSE_FORMAT_XML** or
      **MURL_RESPONSE_FORMAT_JSON** (optional, default
      **MURL_RESPONSE_FORMAT_XML**).
    *proxy*
      HTTP proxy (optional).
    *proxy_username*
      Proxy username (optional).
    *proxy_password*
      Proxy password (optional).

    Murl has following attributes:
    *key*
      API key.
    *format*
      Response format. Must be one of **MURL_RESPONSE_FORMAT_XML** or
      **MURL_RESPONSE_FORMAT_JSON**.

    To enable or disable proxy use method `set_proxy()`. Use method
    `get(long_url)` to get short link.
      
    Use following attributes to get information from the server:
    (Look at <http://murl.kz/about/api> for API fields explanation)
    *status*
      Use it to get status of the request to the server:
      **MURL_STATUS_OK** - request successful,
      **MURL_STATUS_ERROR** - something went wrong.
    *message*
      Status message, e.g. error description.
    *code*
      Status code, e.g. **200**, **400**, etc.
    *url*
      Short link.
    *murlpath*
      Short URL path.
    
    """
    def __init__(self, key, format=MURL_RESPONSE_FORMAT_XML,
                 proxy=None, proxy_username=None, proxy_password=None):
        # API settings
        self._api_key = key
        self._api_format = format
        self._api_handler = "http://api.murl.kz/basic"

        # Murl status
        self._status = None
        # Reply fields
        self._fields = {"message": u"",
                        "code": u"",
                        "url": u"",
                        "murlpath": u""
                        }

        # Raw server reply
        self._reply = u""

        # Setup proxy
        self.set_proxy(proxy, proxy_username, proxy_password)

        
    @property
    def status(self):
        """Get Murl status"""
        return self._status

    @property
    def message(self):
        """Get reply message"""
        return self._fields["message"]

    @property
    def code(self):
        """Get status code"""
        return self._fields["code"]

    @property
    def url(self):
        """Get result url"""
        return self._fields["url"]

    @property
    def murlpath(self):
        """Get murl path"""
        return self._fields["murlpath"]
    
    @property
    def reply(self):
        """Get raw server reply"""
        return self._reply
    

    # API key
    def get_key(self):
        return self._api_key

    def set_key(self, value):
        self._api_key = value

    key = property(get_key, set_key, None, "API key")

    # API format
    def get_format(self):
        return self._api_format

    def set_format(self, value):
        self._api_format = value

    format = property(get_format, set_format, None, "API format")


    def _request(self, query):
        """Send HTTP GET request"""
        req = urllib2.Request(query)
        try:
            response = urllib2.urlopen(req)
        except urllib2.HTTPError, e:
            raise MurlError(u"Server responded with: %s." % (e.message), e)
        except urllib2.URLError, e:
            raise MurlError(u"Failed to connect to server.", e)

        return response

    def set_proxy(self, proxy, proxy_username=None, proxy_password=None):
        """Set proxy

        Arguments:
          *proxy*
            HTTP proxy. Set to None to disable proxy.
          *proxy_username*
            Proxy username (optional).
          *proxy_password*
            Proxy password (optional).
            
        """
        if proxy:
            proxy_handler = urllib2.ProxyHandler({'http': proxy})
            # Use authentication if username and password provided
            if proxy_username and proxy_password:
                password_mgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
                password_mgr.add_password(None, proxy, proxy_username,
                                          proxy_password)
                opener = urllib2.build_opener(
                    NoRedirect(),
                    proxy_handler,
                    urllib2.ProxyBasicAuthHandler(password_mgr),
                    urllib2.ProxyDigestAuthHandler(password_mgr)
                    )
            else:
                opener = urllib2.build_opener(NoRedirect(), proxy_handler)
        else:
            opener = urllib2.build_opener(NoRedirect())

        urllib2.install_opener(opener)

    def get(self, resource):
        """Get short link for resource

        Arguments:
        *resource*
          Long URL

        Function returns True if request successful and False in case of error.

        """
        # Don't allow empty URLs
        if not resource:
            raise MurlError(u"Empty URL!")

        if self.format == MURL_RESPONSE_FORMAT_XML:
            f = MurlXmlResponse()
        elif self.format == MURL_RESPONSE_FORMAT_JSON:
            f = MurlJsonResponse()
        else:
            raise MurlError(u"API format must be one of XML or JSON!")

        # Build query string
        f.build_query_string({"format": f.format_str,
                              "api_key": self.key,
                              "url": resource})
        # Build URL
        url = "%s?%s" % (self._api_handler, f.query_string)

        # Murlificate
        result = self._request(url)
        self._reply = result.read()
        
        # Decode raw server reply
        if f.parse(self._reply):
            self._status = f.status
            self._fields = f.fields
            return True
        else:
            return False

    def demurl(self, m_url):
        """Returns an original URL from short link.

        Arguments:
        *m_url*
          Murl link.
          
        Returns None if m_url doesn't exist in Murl database.

        """
        # Check for correct murl
        k = re.compile("^http://murl\.kz/[\w]{4}$")
        v = k.search(m_url)
        if not v:
            raise MurlError(u"Not correct murl!")
            
        result = None
        r = self._request(m_url)
        try:
            if r.has_key("location"):
                result = r["location"]
        except:
            pass
            
        return result
