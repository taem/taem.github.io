# -*- coding: utf-8 -*-
# 2008-08, Erik Svensson <erik.public@gmail.com>

from constants import *
from transmission import TransmissionError, Torrent, Session, Client

__author__    = u'Erik Svensson <erik.public@gmail.com>'
__version__   = u'0.3'
__copyright__ = u'Copyright (c) 2008 Erik Svensson'
__license__   = u'MIT'
