/* Define if your mailer accepts the subject in the body of the mail */
#undef CL_SUBJ

/* Define to the location of the default config file */
#undef CONF_FILE

/* Define if you have getopt() */
#undef HAVE_GETOPT

/* Define to the location of the default mail program */
#undef MAIL_PROG

/* Version (set by configure) */
#undef VERSION
