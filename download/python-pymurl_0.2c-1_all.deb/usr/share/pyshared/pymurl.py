# -*- coding: utf-8 -*-
"""
Copyright (C) 2009 Timur Birsh

This file is part of PyMurl - Murl.kz API implementation

PyMurl is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

PyMurl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

@author: Timur Birsh <taem@linukz.org>

"""

# Enable absolute imports
from __future__ import absolute_import

# HTTP
import urllib
import urllib2

# XML
from xml.dom import minidom

class MurlError(Exception):
    """Base Murl exception"""
    def __init__(self, message="", original=None):
        Exception.__init__(self, message)
        self.original = original
        
class Murl(object):
    """Main Murl class

    Arguments:
    *key*
      API key.
    *format*
      Response format. Must be one of **xml** or **json** (optional,
      default **xml**).
    *method*
      API method. Only **basic** currently supported (optional).

    Murl has following attributes:
    *key*
      API key.
    *format*
      Response format. Must be one of **xml** or **json**.
    *method*
      API method. Only **basic** currently supported.

    Use method `get(long_url)` to get short link.
      
    Use following attributes to get information from the server:
    (Look at <http://murl.kz/about/api> for API fields explanation)
    *status*
      Use it to get status of the request to the server: **OK** -
      request successful, **ERROR** - something goes wrong.
    *message*
      Status message, e.g. error description.
    *code*
      Status code, e.g. **200**, **400**, etc.
    *url*
      Short link.
    *murlpath*
      Short URL path.
    
    """
    def __init__(self, key, format="xml", method="basic"):
        # API settings
        self._apiKey = key
        self._apiFormat = format
        self._apiMethod = method
        self._apiHandler = "http://api.murl.kz"
        
        self._apiMethods = {"basic": "%s/basic" % self._apiHandler}
        self._apiFormats = {"xml": "XML",
                            "json": "JSON"
                            }

        # Responses
        self._apiResponses = {"ok": u"OK",
                              "error": u"ERROR"
                              }

        # Reply fields
        self._fields = {"status": u"",
                        "message": u"",
                        "code": u"",
                        "url": u"",
                        "murlpath": u""
                        }

        # Raw server reply
        self._reply = u""
        
    @property
    def status(self):
        """Get status - *response* field"""
        return self._fields["status"]

    @property
    def message(self):
        """Get reply message"""
        return self._fields["message"]

    @property
    def code(self):
        """Get status code"""
        return self._fields["code"]

    @property
    def url(self):
        """Get result url"""
        return self._fields["url"]

    @property
    def murlpath(self):
        """Get murl path"""
        return self._fields["murlpath"]
    
    @property
    def reply(self):
        """Get raw server reply"""
        return self._reply
    

    # API key
    def getKey(self):
        return self._apiKey

    def setKey(self, value):
        self._apiKey = value

    key = property(getKey, setKey, None, "API key")

    # API format
    def getFormat(self):
        return self._apiFormat

    def setFormat(self, value):
        self._apiFormat = value

    format = property(getFormat, setFormat, None, "API format")

    # API method
    def getMethod(self):
        return self._apiMethod

    def setMethod(self, value):
        self._apiMethod = value

    method = property(getMethod, setMethod, None, "API method")
    
    def _parseXml(self, x):
        """Parse XML response"""

        # Initialize fields
        fields = {"status": u"",
                  "message": u"",
                  "code": u"",
                  "url": u"",
                  "murlpath": u""
                  }

        # Parse XML
        dom = minidom.parseString(x)
        nodeStatus = dom.getElementsByTagName("status")[0]
        fields["status"] = nodeStatus.attributes["result"].nodeValue
        fields["code"] = nodeStatus.attributes["code"].nodeValue
        fields["message"] = nodeStatus.attributes["message"].nodeValue
        if fields["status"] == self._apiResponses["ok"]:
            fields["url"] = dom.getElementsByTagName("url")[0].firstChild.nodeValue
            fields["murlpath"] = dom.getElementsByTagName("murlpath")[0].firstChild.nodeValue
        
        return fields

    def _parseJson(self, j):
        """Parse JSON response"""
        raise NotImplementedError(u"JSON parsing not yet implemented!")

    def _parse(self, format, data):
        """Parse server reply"""
        if format == "XML":
            return self._parseXml(data)
        elif format == "JSON":
            return self._parseJson(data)
        else:
            raise MurlError(u"Unknown format: %s" % (format))
        
    def _request(self, query):
        """Send HTTP GET request"""
        req = urllib2.Request(query)
        try:
            response = urllib2.urlopen(req)
        except urllib2.HTTPError, e:
            raise MurlError(u"Server responded with: %s." % (e.message), e)
        except urllib2.URLError, e:
            raise MurlError(u"Failed to connect to server.", e)

        data = response.read()
        return data

    def get(self, resource):
        """Get short link for resource

        Arguments:
        *resource*
          Long URL

        """
        # Only "basic" method currently supported
        if self.method != "basic":
            raise MurlError(u"Only 'basic' API method currently supported!")

        # API format must be one of "xml" or "json"
        if self.format not in self._apiFormats:
            raise MurlError(u"API format must be one of 'xml' or 'json'!")

        # Don't allow empty URLs
        if not resource:
            raise MurlError(u"Empty URL!")

        # Build query string
        query = urllib.urlencode({"format": self._apiFormats[self.format],
                                  "api_key": self.key,
                                  "url": resource})
        if self._apiFormats[self.format] == "JSON":
            callback = urllib.urlencode({"callback": "?"})
            query = "%s&%s" % (query, callback)

        # Build URL
        url = "%s?%s" % (self._apiMethods[self.method], query)

        # Murlificate
        self._reply = self._request(url)
        result = self._parse(self._apiFormats[self.format], self._reply)
        if result:
            self._fields = result
